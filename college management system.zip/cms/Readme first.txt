college management system...

principal login

username: principal
password: 123


faculty login

username: plitstaff 
password: staff@plit

*must run main.php file*